#include "peripheralManager.h"

PeripheralManager peripheralManager;

void setup() {
  peripheralManager.Setup();

}


void loop() {
  peripheralManager.Loop();
}